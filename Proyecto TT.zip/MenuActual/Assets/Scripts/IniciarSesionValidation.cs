﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;
using UnityEngine.SceneManagement;

public class IniciarSesionValidation : MonoBehaviour {

    private string usuario;
    private string contrasena;

    public GameObject UsuarioInput;
    public GameObject PassInput;

    public GameObject IniciarButton;

    public GameObject MSGECompletaCampos;
    public GameObject MSGEError;
    public GameObject MSGEUsuarioCIncorrectos;
    
    public LoadSceneOnClick cargarEscena;


    // Use this for initialization
    void Start() {
        ocultarMensajes();

        Button iniciarSesion = IniciarButton.GetComponent<Button>();
        iniciarSesion.onClick.AddListener(LogIn);
    }

    public void LogIn()
    {
        usuario = UsuarioInput.GetComponent<InputField>().text;
        contrasena = PassInput.GetComponent<InputField>().text;

        
        if (contrasena == "" || usuario == ""){
            MSGECompletaCampos.GetComponent<Text>().enabled = true;
        }
        else{
            SceneManager.LoadScene(3);
        }
        

    }

    public void ocultarMensajes(){
        MSGEError.GetComponent<Text>().enabled = false;
        MSGECompletaCampos.GetComponent<Text>().enabled = false;
        MSGEUsuarioCIncorrectos.GetComponent<Text>().enabled = false;
    }
	
	// Update is called once per frame
	void Update () {
        
        

	}


}
