﻿using System.Collections.Generic;
using System.Net;
using UnityEngine;
using UnityEngine.UI;
using SimpleJSON;
using System;
using System.Collections;
using UnityEngine.Networking;

public class CatalogoEscuelas : MonoBehaviour {


    /*----------------------------------------*/
    /*------------- OPCION 1 -----------------*/
    /*----------------------------------------*/
    
    public Dropdown EscuelaDropdown;


    [Serializable]
    public class Schools
    {
        public int idEscuela;        
        public string Nombre;
    }

    void Start()
    {

        StartCoroutine(GetText());

    
    }

    IEnumerator GetText()
    {
        string url = "http://13.59.121.139:5000/v1/everyone/getEscuelas";
        UnityWebRequest www = UnityWebRequest.Get(url);
        yield return www.Send();

        if (www.isError)
        {
            Debug.Log(www.error);
        }
        else
        {
            // Show results as text
            Debug.Log(www.downloadHandler.text);

            // Or retrieve results as binary data
            byte[] results = www.downloadHandler.data;

            Schools myObject = new Schools();
            string json = JsonUtility.ToJson(www.downloadHandler.text);
            if (json.Length != 0)
            {
                Debug.Log(json.Length);
                myObject = JsonUtility.FromJson<Schools>(json);
                Debug.Log(json);
                Debug.Log(myObject.Nombre);
                Debug.Log(myObject);
            }
            else
            {
                Debug.Log("Errores");
            }

        }
    }
    

    /*----------------------------------*/
    /*----------OPCION DOS -------------*/
    /*-----------------------------------*/
    /*
    public Dropdown EscuelaDropdown;


    [Serializable]
    public class Schools
    {
        public int idEscuela;
        public string Nombre;
    }

    void Start()
    {

        StartCoroutine(GetText());


    }

    IEnumerator GetText()
    {
        string url = "http://13.59.121.139:5000/v1/everyone/getEscuelas";
        UnityWebRequest www = UnityWebRequest.Get(url);
        yield return www.Send();

        if (www.isError)
        {
            Debug.Log(www.error);
        }
        else
        {
            // Show results as text
            Debug.Log(www.downloadHandler.text);

            // Or retrieve results as binary data
            byte[] results = www.downloadHandler.data;

            Schools myObject = new Schools();
            string json = JsonUtility.ToJson(www.downloadHandler.text);
            if (json.Length != 0)
            {
                Debug.Log(json.Length);
                myObject = JsonUtility.FromJson<Schools>(json);
                Debug.Log(json);
                Debug.Log(myObject.Nombre);
                Debug.Log(myObject);
            }
            else
            {
                Debug.Log("Errores");
            }

        }
    }
    */


    /*-------------------------------------------*/
    /*----------------OPCION TRES-----------------*/
    /*------------------------------------------*/
    /*
    public Dropdown EscuelaDropdown;

    public Escuelas[] items { get; set; }

    // Use this for initialization
    void Start()
    {
        //getCatalogoEscuelas();

        WebRequest request = WebRequest.Create("http://13.59.121.139:5000/v1/everyone/getEscuelas");
        request.Method = "GET";
        WebResponse response = request.GetResponse();

        string json = JsonUtility.ToJson(response);
        //Escuelas myObject = JsonUtility.FromJson<Escuelas>(json);
        //Debug.Log(json);

        //string json = "{ \"IdEscuela\":\"3\",\"Nombre\":\"Ignacio Zaragoza\"}";
        //Escuelas e = Escuelas.CreateFromJSON(json);


        Escuelas list = Escuelas.CreateFromJSON(json);

        
        //Debug.Log("------------RESULTADS--------------------");
        //Debug.Log(list.items[0].Nombre);
       // Debug.Log(list.items[1].Nombre);


        eba1();



    }
    /

    public class MyClassList
    {
        public List<Escuelas> items;

        public static MyClassList CreateFromJSON(string jsonString)
        {
            return JsonUtility.FromJson<MyClassList>(jsonString);
        }

        public MyClassList()
        {
            items = new List<Escuelas>();
        }
    }



    public void getCatalogoEscuelas()
    {
        //Url = "http://13.59.121.139:5000/v1/everyone/getEscuelas";
        //escuelas = new Escuelas();
       // WWW www = new WWW(Url);
        //StartCoroutine("GetdataEnumerator", Url);

        WebRequest request = WebRequest.Create("http://13.59.121.139:5000/v1/everyone/getEscuelas");
        request.Method = "GET";
        WebResponse response = request.GetResponse();
        //Debug.Log("RESPUESTA: ");
        //Debug.Log(response);
        //Debug.Log(JsonUtility.ToJson(response));

        string json = JsonUtility.ToJson(response);

        EscuelaDropdown.options.Clear();

        EscuelaDropdown.ClearOptions();

        //Escuelas pd = CreateFromJSON(json);

        // Debug.Log("Que onda : " + pd.nombre);

        //Debug.Log("SERÁ ?  = " + pd.nombre[0]);

        //EscuelaDropdown.options.Add(new Dropdown.OptionData(pd.nombre[0].ToString));

        
         //int a = json.Length; Debug.Log("Longitd : "+ a);
         //int y = 0;
         //string b = "";
         //while (a > y)
         //{

         //    b = JsonUtility.FromJson<String>(json);
         //    EscuelaDropdown.options.Add(new Dropdown.OptionData(b));
         //    Debug.Log(b);
         //    y++;
         //}

        

        //foreach (string str in data)
        //{
        //    EscuelaDropdown.options.Add(new Dropdown.OptionData(str));
        //}

        // RootObject instance = JsonConvert.Deserialize<RootObject>(b);

        //var firstName = instance.People[0].idEscuela;
        // var lastName = instance.People[0].nombre;

        //EscuelaDropdown.AddOptions(json);
    }


    public void eba1()
    {
        WWW www;

        IEnumerator Start()
        {
            string url = "http://13.59.121.139:5000/v1/everyone/getEscuelas";
            www = new WWW(url);
            yield return www;
            string json = www.text;
            JsonClass jc = JsonUtility.FromJson<JsonClass>(json);
        }


    [System.Serializable]
    public class JsonClass
    {
        public List<MyClass> mc;
    }

    [System.Serializable]
    public class MyClass
    {
        public int ID;
        public string Char_name;
    }
}
*/



}
