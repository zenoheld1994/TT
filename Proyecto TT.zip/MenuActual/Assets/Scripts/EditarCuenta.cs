﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;
using UnityEngine.SceneManagement;


public class EditarCuenta : MonoBehaviour {

    private string usuario;
    private string contrasena;
    private string confirmacion;
    private string nombre;
    private int escuela;

    public GameObject UsuarioInput;
    public GameObject PassInput;
    public GameObject ConfirmarInput;
    public GameObject NombreUsuarioInput;
    public GameObject EscuelaDropdown;
    public GameObject EditarCuentaButton;

    public GameObject MSGEError;
    public GameObject MSGECompleta;
    public GameObject MSGEUsuario;
    public GameObject MSGEContrasena;

    // Use this for initialization
    void Start () {
        ocultarMensajes();

        Button editarButton = EditarCuentaButton.GetComponent<Button>();
        editarButton.onClick.AddListener(EditCuenta);
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ocultarMensajes()
    {
        MSGEError.GetComponent<Text>().enabled = false;
        MSGECompleta.GetComponent<Text>().enabled = false;
        MSGEContrasena.GetComponent<Text>().enabled = false;
        MSGEUsuario.GetComponent<Text>().enabled = false;

    }

    public void EditCuenta()
    {
        usuario = UsuarioInput.GetComponent<InputField>().text;
        contrasena = PassInput.GetComponent<InputField>().text;
        confirmacion = ConfirmarInput.GetComponent<InputField>().text;
        nombre = NombreUsuarioInput.GetComponent<InputField>().text;
        escuela = EscuelaDropdown.GetComponent<Dropdown>().value;

        if (usuario == "" && contrasena == "" && confirmacion == "" && nombre == "")
        {
            ocultarMensajes();
            MSGECompleta.GetComponent<Text>().enabled = true;
        }
        else if (contrasena != confirmacion)
        {
            ocultarMensajes();
            MSGEContrasena.GetComponent<Text>().enabled = true;
        }
        else
        {
            ocultarMensajes();
            SceneManager.LoadScene(3);
        }
    }
}
