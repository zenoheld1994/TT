﻿using System.Net;
using UnityEngine;
using UnityEngine.UI;


public class Rootobject
{
    public int count { get; set; }
    /*public Escuelas[] items { get; set; }*/
    public string Nombre { get; set; }
    public int IdEscuela { get; set; }

    public static Escuelas CreateFromJSON(string jsonString)
    {
        return JsonUtility.FromJson<Escuelas>(jsonString);
    }
}

[System.Serializable]
public class Escuelas
{
    public int count { get; set; }
    public string Nombre { get; set; }
    public int IdEscuela { get; set; }

    public static Escuelas CreateFromJSON(string jsonString)
    {
        return JsonUtility.FromJson<Escuelas>(jsonString);
    }
    

    // Given JSON input:
    // {"name":"Dr Charles","lives":3,"health":0.8}
    // this example will return a PlayerInfo object with
    // name == "Dr Charles", lives == 3, and health == 0.8f.
}