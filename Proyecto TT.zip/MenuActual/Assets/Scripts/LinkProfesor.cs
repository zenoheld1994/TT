﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LinkProfesor : MonoBehaviour {

    public void linkProfesor()
    {
        Application.OpenURL("http://13.59.121.139:5000/login_page");
    }

}
