﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class getInformacion : MonoBehaviour {

    public Dropdown EscuelaDropdown;

    public Escuelas[] items { get; set; }

    void Start()
    {
        //StartCoroutine(GetText());
    }

    IEnumerator GetText()
    {
        StartCoroutine(GetText());


        // Or retrieve results as binary data
        byte[] results = www.downloadHandler.data;

            // Show results as text
            string responseText = www.downloadHandler.text;
            Debug.Log(responseText);
            //Debug.Log(www);
           

            string json = JsonUtility.ToJson(responseText);

            Escuelas list = Escuelas.CreateFromJSON(json);

            Debug.Log("***JOSN***");

            // Or retrieve results as binary data
            Debug.Log(json);
            Debug.Log("**********");
            
            Debug.Log(results);

            Debug.Log("RESULTADS--------------------");
            
           // Debug.Log(list[0].IdEscuela);

            

        }

    
    }
    

    public class MyClassList
    {
        public List<Escuelas> items;

        public static MyClassList CreateFromJSON(string jsonString)
        {
            return JsonUtility.FromJson<MyClassList>(jsonString);
        }

        public MyClassList()
        {
            items = new List<Escuelas>();
        }
    }
}
